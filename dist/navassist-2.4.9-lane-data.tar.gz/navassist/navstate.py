"""The navigation payload published on pluginMsg kind "nav.state" (JSON for other plugins and the HUD)."""
from __future__ import annotations

MAX_PHONE_LOCATION_AGE_MS = 1_000
MAX_PHONE_LANE_GUIDANCE_AGE_MS = 10_000  # AMap re-emits lane items irregularly; 2 s dropped most of them
MAX_PHONE_LOCATION_ACCURACY_M = 25.0

MANEUVERS = frozenset((
  "none", "straight", "slight_left", "slight_right", "turn_left", "turn_right", "sharp_left", "sharp_right",
  "u_turn_left", "u_turn_right", "keep_left", "keep_right", "merge_left", "merge_right", "exit_left",
  "exit_right", "ramp_left", "ramp_right", "roundabout", "destination", "unknown",
))


def empty_state(reason: str = "noData") -> dict:
  return {"valid": False, "stale": True, "reason": reason, "maneuver": "none", "distanceM": 0.0,
          "nextManeuver": "none", "nextDistanceM": 0.0, "lanes": [], "laneTotalCount": -1,
          "sessionId": "", "routeRevision": 0, "maneuverEventId": 0, "sequence": 0,
          "currentStepIndex": -1, "currentLinkIndex": -1, "currentPointIndex": -1,
          "sourceWallTimeMs": 0, "ageMs": 0.0, "advisorySpeedMps": 0.0, "routeActive": False,
          "source": "", "mode": "idle", "navRouteActive": False}


def _phone_observations_valid(snapshot) -> bool:
  location_age_ms = snapshot.source_wall_time_ms - snapshot.location_observed_at_ms
  # PARKED_LOCATION_RELAX：停车时高德不重复回调位置，年龄会一直增长；
  # 车速接近 0 时放宽到 5 秒，行驶中仍要求 1 秒内。
  parked = float(getattr(snapshot, 'speed_kph', 0.0) or 0.0) < 5.0
  budget_ms = 5_000 if parked else MAX_PHONE_LOCATION_AGE_MS
  return bool(
    snapshot.coordinate_system != "unknown"
    and snapshot.accuracy_m <= MAX_PHONE_LOCATION_ACCURACY_M
    and 0 <= location_age_ms <= budget_ms
  )


AUTO_ROAD_KIND = {0: "expressway", 1: "national", 6: "urban_expressway"}
SDK_ROAD_KIND = {1: "expressway", 2: "national", 3: "provincial", 4: "county", 5: "town",
                 6: "ramp", 8: "ramp", 9: "ramp", 10: "ramp", 56: "ramp", 58: "ramp"}
HIGHWAY_NAME_HINTS = ("高速", "高架", "快速", "环路", "环线")
# 车主指定的快速化城市道路：路名匹配时按快速路处理，允许导航超车。
USER_ROAD_WHITELIST = ("桂丹路", "禅西大道")
FREEWAY_KINDS = frozenset(("expressway", "urban_expressway"))
VALID_HOLD_NS = 1_500_000_000
_valid_hold = 0
_valid_hold_key = None


def road_kind(road_class, road_type, *, road_name="", speed_kph=0.0,
              parallel_status="unknown", elevated_status="unknown") -> str:
  name = road_name or ""
  on_side_layer = parallel_status == "side" or elevated_status == "side"
  if any(h in name for h in HIGHWAY_NAME_HINTS) and not on_side_layer and speed_kph >= 45.0:
    return "urban_expressway" if any(h in name for h in ("高架", "快速", "环路", "环线")) else "expressway"
  # 白名单道路：桂丹路、禅西大道等快速化主干道，允许超车（仍需车速达标）。
  if any(h in name for h in USER_ROAD_WHITELIST) and not on_side_layer and speed_kph >= 45.0:
    return "urban_expressway"
  kind = SDK_ROAD_KIND.get(road_type) or AUTO_ROAD_KIND.get(road_class) or "unknown"
  if kind in FREEWAY_KINDS and speed_kph < 55.0:
    return "unknown"
  return kind


def build(current, now_ns: int, *, oem_nav_route_active: bool = False) -> dict:
  """Control-valid only for a fresh, matched realtime Android/iOS route with guidance."""
  global _valid_hold, _valid_hold_key
  if current is None:
    _valid_hold, _valid_hold_key = 0, None
    return empty_state()
  from .cpnav import CPStore
  if isinstance(current, CPStore):
    _valid_hold, _valid_hold_key = 0, None
    return current.normalized(now_ns)
  snapshot = current.snapshot
  stale = current.is_stale(now_ns)
  lane_guidance_age_ms = snapshot.source_wall_time_ms - snapshot.lane_guidance_observed_at_ms
  lane_valid = bool(snapshot.lane_guidance_present and 0 <= lane_guidance_age_ms <= MAX_PHONE_LANE_GUIDANCE_AGE_MS)
  control_source_valid = snapshot.source_platform in ("android", "ios") and snapshot.navigation_mode == "realtime"
  phone_observations_valid = _phone_observations_valid(snapshot)
  guidance_age = snapshot.source_wall_time_ms-snapshot.guidance_observed_at_ms
  # GUIDANCE_STALE_PARKED：高德只在距离变化时回调引导，停着不动引导时间戳会一直变老。
  # 车速接近 0 时放宽到 60 秒（机动信息本身没变），行驶中仍要求 1.5 秒内。
  _parked = float(getattr(snapshot, 'speed_kph', 0.0) or 0.0) < 5.0
  # 停着不动时引导时间戳会无限变老（高德只在距离变化时回调），此时只看"有没有引导"。
  guidance_valid = bool(snapshot.guidance_present
                        and ((_parked and guidance_age >= 0) or (0 <= guidance_age <= 1500)))
  # AMap need not repeat unchanged maneuver callbacks. As on the 23-Oct
  # baseline, a fresh matched snapshot keeps turn-only guidance available.
  # Lane/slowdown validity below still requires recent guidance and positioning.
  guidance_known = snapshot.guidance_present and guidance_age >= 0
  linked = bool(not stale and control_source_valid and snapshot.route_active and snapshot.route_matched
                and guidance_known and snapshot.location_present)
  valid = bool(not stale and control_source_valid and snapshot.route_active and snapshot.route_matched
               and snapshot.location_present and guidance_valid and not snapshot.gps_weak and phone_observations_valid)
  if stale:
    reason = "stale"
  elif not control_source_valid or not snapshot.route_active:
    reason = "noData"
  elif not snapshot.route_matched:
    reason = "routeUnmatched"
  elif not snapshot.location_present or not snapshot.guidance_present:
    reason = "noData"
  elif not guidance_valid:
    reason = "guidanceStale"
  elif snapshot.gps_weak:
    reason = "gpsWeak"
  elif not phone_observations_valid:
    reason = "phoneLocalization"
  else:
    reason = "none"
  hold_key = (snapshot.session_id, snapshot.route_revision, snapshot.maneuver_event_id)
  if valid:
    _valid_hold, _valid_hold_key = now_ns, hold_key
  elif (not stale and control_source_valid and snapshot.route_active and snapshot.route_matched
        and _valid_hold_key == hold_key and _valid_hold and 0 <= now_ns - _valid_hold <= VALID_HOLD_NS):
    valid = True
    if reason != "stale":
      reason = "none"
  else:
    _valid_hold, _valid_hold_key = 0, None
  lanes = []
  if lane_valid:
    for lane in snapshot.lanes:
      lanes.append({"index": lane.index, "allowedActions": lane.allowed_actions,
                    "recommendedActions": lane.recommended_actions, "recommended": lane.recommended})
  return {
    "valid": valid, "stale": stale, "reason": reason, "linked": linked,
    "maneuver": snapshot.maneuver, "distanceM": snapshot.maneuver_distance_m,
    "nextManeuver": snapshot.next_maneuver, "nextDistanceM": snapshot.next_maneuver_distance_m,
    "lanes": lanes, "laneTotalCount": snapshot.lane_total_count,
    "sessionId": snapshot.session_id, "routeRevision": snapshot.route_revision,
    "maneuverEventId": snapshot.maneuver_event_id, "sequence": snapshot.sequence,
    "currentStepIndex": snapshot.current_step_index,
    "currentLinkIndex": snapshot.current_link_index,
    "currentPointIndex": snapshot.current_point_index,
    "sourceWallTimeMs": snapshot.source_wall_time_ms, "ageMs": current.age_ms(now_ns),
    "advisorySpeedMps": snapshot.advisory_speed_mps or 0.0, "routeActive": snapshot.route_active,
    "source": snapshot.source_platform, "mode": snapshot.navigation_mode,
    "navRouteActive": oem_nav_route_active,
  }
