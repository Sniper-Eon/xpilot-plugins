"""
Copyright (c) 2021-, Haibin Wen, sunnypilot, and a number of other contributors.

Adapted from onemiless/opendbc 65cc8fdbcb6aaaf0533ba296c9e6fe5422a696e8.
This software is licensed under a custom license requiring permission for use.
See LICENSE.md in this plugin directory.
"""
import math
import numpy as np
from collections import namedtuple
from dataclasses import replace

from opendbc.car import rate_limit, DT_CTRL
from opendbc.car.vehicle_model import VehicleModel
from opendbc.car.lateral import apply_steer_angle_limits_vm
from opendbc.car.tesla.values import CarControllerParams
from opendbc.car.tesla.carcontroller import get_safety_CP
from openpilot.selfdrive.controls.lib.latcontrol_angle import LatControlAngle


DT_LAT_CTRL = DT_CTRL * CarControllerParams.STEER_STEP

# limit steering acceleration when engaging
STEER_RESUME_RATE_LIMIT_RAMP_RATE = 300 # deg/s^2

class CoopSteeringCarControllerParams(CarControllerParams):
  ANGLE_LIMITS = replace(CarControllerParams.ANGLE_LIMITS, MAX_ANGLE_RATE=5)

# angle override # todo implement steering torque inertia compensation to increase gains
STEER_OVERRIDE_MIN_TORQUE = 0.5 # Nm - based on typical steering bias + noise - used for the deadzone
STEER_OVERRIDE_MAX_TORQUE = 2.5 # Nm - typical torque before EPS disengages due to hands_on_level=3
STEER_OVERRIDE_TORQUE_RANGE = STEER_OVERRIDE_MAX_TORQUE - STEER_OVERRIDE_MIN_TORQUE

STEER_OVERRIDE_STANDSTILL_VEGO = 0.1 # m/s - below this speed holding-torque estimate collapses (angle/torque_to_angle blows up)
STEER_OVERRIDE_MAX_LAT_ACCEL = 2.0 # m/s^2 - determines angle rate - speed dependent - similar to Tesla comfort steering mode
STEER_OVERRIDE_TARGET_ANGLE_MAX = CarControllerParams.ANGLE_LIMITS.STEER_ANGLE_MAX  # deg

# override angle ramp control
STEER_OVERRIDE_DELTA_GAIN_LIMIT = 125 # deg/s/Nm
STEER_OVERRIDE_DELTA_GAIN_LIMIT_CENTERING = CoopSteeringCarControllerParams.ANGLE_LIMITS.MAX_ANGLE_RATE / DT_LAT_CTRL / STEER_OVERRIDE_TORQUE_RANGE

CoopSteeringDataSP = namedtuple("CoopSteeringDataSP",
                                ["steeringAngleDeg", "lat_active"])

def get_steer_from_lat_accel(lat_accel, vEgo: float, VM: VehicleModel):
  """Calculate the maximum steering angle based on lateral acceleration."""
  curvature = lat_accel / (max(1, vEgo) ** 2)  # 1/m
  return math.degrees(VM.get_steer_from_curvature(curvature, vEgo, 0))  # deg


def apply_bounds(signal: float, limit: float) -> float:
  """Limit input to a range."""
  return float(np.clip(signal, -limit, limit))


def apply_deadzone(signal: float, deadzone: float) -> float:
  """Apply deadzone to input."""
  return signal - apply_bounds(signal, deadzone)


def get_override_torque_to_angle(vEgo: float, VM: VehicleModel, lat_accel: float) -> float:
  """
  Convert effective override torque to steering angle gain.
  """

  # lateral accel is linear in respect to angle so it's fine to interpolate it with torque
  steer_from_lat_accel = apply_bounds(get_steer_from_lat_accel(lat_accel, vEgo, VM), STEER_OVERRIDE_TARGET_ANGLE_MAX)
  return steer_from_lat_accel / STEER_OVERRIDE_TORQUE_RANGE


def calc_override_angle_delta_limit(torque: float, gain_limit: float) -> float:
  """
  Convert torque magnitude to a per-step steering angle delta limit.
  """
  delta_gain_limit_max = CoopSteeringCarControllerParams.ANGLE_LIMITS.MAX_ANGLE_RATE / DT_LAT_CTRL / STEER_OVERRIDE_TORQUE_RANGE
  return torque * min(gain_limit, delta_gain_limit_max) * DT_LAT_CTRL


class SteerRateLimiter:
  """Handles rate limiting of steering angle changes with a configurable rate."""
  def __init__(self):
    self._last = 0.0

  def reset(self, angle: float) -> None:
    """Reset the rate limiter state with the given angle."""
    self._last = angle

  def update(self, angle: float, angle_delta_lim: float) -> float:
    angle_lim = rate_limit(angle, self._last, -angle_delta_lim, angle_delta_lim)
    self._last = angle_lim
    return angle_lim


class CoopSteeringCarController:
  def __init__(self):
    self.apply_angle_last = 0
    self.coop_apply_angle_sat_last = 0
    self.angle_override = 0
    self.resume_rate_limiter_delta = SteerRateLimiter()
    self.resume_rate_limiter = SteerRateLimiter()

  def reset_override_state(self, apply_angle: float) -> None:
    self.apply_angle_last = apply_angle
    self.angle_override = 0
    self.coop_apply_angle_sat_last = apply_angle

  def compute_override_targets(self, vEgo: float, steering_torque: float, VM: VehicleModel) -> tuple[float, float]:
    """Returns (angle_override_target, override_torque): driver's target angle and net torque above neutral."""
    torque_to_angle = get_override_torque_to_angle(vEgo, VM, STEER_OVERRIDE_MAX_LAT_ACCEL)
    driver_torque_with_deadzone = apply_deadzone(steering_torque, STEER_OVERRIDE_MIN_TORQUE)
    neutral_torque = 0.0 if abs(vEgo) <= STEER_OVERRIDE_STANDSTILL_VEGO else self.angle_override / torque_to_angle
    return driver_torque_with_deadzone * torque_to_angle, driver_torque_with_deadzone - neutral_torque

  def override_slew_step(self, angle_override_target: float, override_torque: float) -> float:
    """Per-frame slew toward driver torque target; slew rate scales with excess torque (asymmetric away vs centering)."""
    target_error = angle_override_target - self.angle_override

    slew_rate_away = calc_override_angle_delta_limit(abs(override_torque), STEER_OVERRIDE_DELTA_GAIN_LIMIT)
    slew_rate_center = calc_override_angle_delta_limit(abs(override_torque), STEER_OVERRIDE_DELTA_GAIN_LIMIT_CENTERING)

    down_step = slew_rate_center if self.angle_override > 0 else slew_rate_away
    up_step = slew_rate_center if self.angle_override < 0 else slew_rate_away

    return float(np.clip(target_error, -down_step, up_step))

  @staticmethod
  def adjust_slew_for_planner(slew_step: float, apply_angle_step: float, override_torque: float) -> float:
    """
    Same-direction: subtract planner overlap to avoid double-counting.
    Opposing: grow slew opposite to planner, scaled by driver effort.
    """
    direction = slew_step * apply_angle_step
    if direction > 0:
      return slew_step - apply_bounds(apply_angle_step, abs(slew_step))
    if direction < 0:
      driver_effort = abs(override_torque) / STEER_OVERRIDE_TORQUE_RANGE
      return slew_step - driver_effort * apply_angle_step
    return slew_step

  @staticmethod
  def unwind_on_saturation(angle_override: float, sat_error: float) -> float:
    """Anti-windup: if override drove past the angle limit, pull it back by the overshoot."""
    if angle_override * sat_error <= 0:
      return angle_override
    return angle_override - apply_bounds(sat_error, abs(angle_override))

  def resume_steer_desired_rate_limit(self, lat_active: bool, apply_angle: float) -> float:
    """Limits steering wheel acceleration when resuming steering"""
    if not lat_active:
      # reset and bypass
      self.resume_rate_limiter_delta.reset(0)
      self.resume_rate_limiter.reset(apply_angle)
      return apply_angle

    angle_rate_delta_lim = self.resume_rate_limiter_delta.update(CarControllerParams.ANGLE_LIMITS.MAX_ANGLE_RATE,
                                                         STEER_RESUME_RATE_LIMIT_RAMP_RATE * DT_LAT_CTRL**2)
    apply_angle_lim = self.resume_rate_limiter.update(apply_angle, angle_rate_delta_lim)
    return apply_angle_lim

  def update(self, apply_angle, lat_active, CS, VM: VehicleModel) -> CoopSteeringDataSP:
    # avoid sudden rotation on engagement
    apply_angle = self.resume_steer_desired_rate_limit(lat_active, apply_angle)

    if not lat_active:
      self.reset_override_state(apply_angle)
      return CoopSteeringDataSP(apply_angle, lat_active)

    apply_angle_step = apply_angle - self.apply_angle_last
    self.apply_angle_last = apply_angle

    angle_override_target, override_torque = self.compute_override_targets(CS.vEgo, CS.steeringTorque, VM)
    slew_step = self.override_slew_step(angle_override_target, override_torque)
    slew_step = self.adjust_slew_for_planner(slew_step, apply_angle_step, override_torque)
    self.angle_override += slew_step

    apply_angle += self.angle_override

    # final rate limit - matching panda safety
    self.coop_apply_angle_sat_last = apply_steer_angle_limits_vm(apply_angle, self.coop_apply_angle_sat_last, CS.vEgoRaw,
                                                    CS.steeringAngleDeg, lat_active, CoopSteeringCarControllerParams, VM)
    sat_error = apply_angle - self.coop_apply_angle_sat_last
    self.angle_override = self.unwind_on_saturation(self.angle_override, sat_error)

    return CoopSteeringDataSP(self.coop_apply_angle_sat_last, lat_active)


class MixedControl(LatControlAngle):
  def __init__(self, CP, CP_SP, CI):
    super().__init__(CP, CP_SP, CI, DT_CTRL)
    self.safety_vm = VehicleModel(get_safety_CP())
    self.coop = CoopSteeringCarController()
    self.frame = 0
    self.pre_limited_angle = 0.0
    self.angle = 0.0

  def reset(self):
    super().reset()
    self.coop = CoopSteeringCarController()
    self.frame = 0

  def update(self, active, CS, VM, params, steer_limited_by_safety, desired_curvature, calibrated_pose, curvature_limited, lat_delay):
    steer, desired, angle_log = super().update(active, CS, VM, params, steer_limited_by_safety, desired_curvature,
                                              calibrated_pose, curvature_limited, lat_delay)
    # Validate every sensor sample, including the held half-cycle, before clipping can hide NaN/inf.
    if not all(math.isfinite(x) for x in (CS.steeringTorque, CS.steeringAngleDeg, CS.vEgo, CS.vEgoRaw, desired)):
      raise ValueError("non-finite mixed control input")
    if not active or self.frame % CarControllerParams.STEER_STEP == 0:
      # Same pipeline as the jetlink branch: blend the driver torque into LatControlAngle's already
      # limited command, then let the single coop rate limiter (and the car port) cap it. The extra
      # CarControllerParams pre-limiter made the override feel lazy, so it is gone.
      self.angle = self.coop.update(desired, active, CS, self.safety_vm).steeringAngleDeg
    self.frame = self.frame + 1 if active else 0
    angle_log.steeringAngleDesiredDeg = self.angle
    return steer, self.angle, angle_log
