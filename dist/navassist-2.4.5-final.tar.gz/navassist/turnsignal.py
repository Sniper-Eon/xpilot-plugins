"""Bounded Tesla DAS_bodyControls (0x3E9, vehicle bus 1) turn-signal requests.

The lamp is cloned from a fresh car frame with turn_request 0; only the turn request, reason, counter and checksum
change. The panda safety plugin 'navassist' re-validates every frame, including the checksum and counter. The
stock DesireHelper sees the resulting CarState blinker and still applies its blind-spot, road-edge and ALC-mode
gates; this module never sends steering, acceleration or a lane-change command."""
from __future__ import annotations

ADDRESS = 0x3E9
BUS = 1
TEMPLATE_MAX_AGE_NS = 1_500_000_000
SEND_INTERVAL_NS = 100_000_000
FEEDBACK_TIMEOUT_NS = 2_500_000_000
CANCEL_TOTAL_TIMEOUT_NS = 9_000_000_000
SESSION_TIMEOUT_NS = 60_000_000_000
MAX_CANCEL_ATTEMPTS = 20
RESEND_NS = 1_000_000_000        # 灯没亮时每秒重发一次请求
MAX_ACTION_ATTEMPTS = 4           # 最多重发 4 次（约 4 秒），避免灯亮太久
TURN_REQUESTS = {"left": 1, "right": 2, "cancel": 3}
ACTIVE_REASON = 8
CANCEL_REASON = 4


def checksum(data: bytes | bytearray) -> int:
  if len(data) != 8:
    raise ValueError("0x3E9 must contain 8 bytes")
  return (0xE9 + 0x03 + sum(data[:7])) & 0xFF


def decode(data: bytes | bytearray) -> dict:
  if len(data) != 8:
    raise ValueError("0x3E9 must contain 8 bytes")
  return {"turn": data[1] & 0x03, "reason": (data[2] >> 1) & 0x0F,
          "counter": (data[6] >> 4) & 0x0F, "checksum": data[7]}


def is_idle_template(address: int, bus: int, data: bytes) -> bool:
  return bool(address == ADDRESS and bus == BUS and len(data) == 8 and checksum(data) == data[7]
              and decode(data)["turn"] == 0)


def build(template: bytes, direction: str, counter: int) -> bytes:
  if direction not in TURN_REQUESTS:
    raise ValueError(f"unsupported turn request: {direction}")
  if not 0 <= counter <= 15:
    raise ValueError("invalid counter")
  if not is_idle_template(ADDRESS, BUS, template):
    raise ValueError("not an idle 0x3E9 template")
  data = bytearray(template)
  data[1] = (data[1] & 0xFC) | TURN_REQUESTS[direction]
  reason = CANCEL_REASON if direction == "cancel" else ACTIVE_REASON
  data[2] = (data[2] & 0xE1) | ((reason & 0x0F) << 1)
  data[6] = (data[6] & 0x0F) | ((counter & 0x0F) << 4)
  data[7] = checksum(data)
  return bytes(data)


class TurnSignalController:
  def __init__(self) -> None:
    self.template: bytes | None = None
    self.template_ns = 0
    self.active: dict | None = None
    self._last_send_ns: int | None = None
    self._failed_key = None

  def reset(self) -> None:
    self.active = None

  def observe(self, can_list, now_ns: int) -> None:
    for _mono, frames in can_list:
      for address, data, bus in frames:
        if is_idle_template(int(address), int(bus), bytes(data)):
          self.template = bytes(data)
          self.template_ns = int(now_ns)

  @staticmethod
  def _key(intent):
    return (intent.get("sessionId"), int(intent.get("routeRevision", 0)),
            int(intent.get("requestId", 0)), str(intent.get("direction", "none")))

  def _can_send(self, now_ns):
    return self._last_send_ns is None or now_ns-self._last_send_ns >= SEND_INTERVAL_NS

  def _emit(self, direction, counter, now_ns):
    self._last_send_ns = int(now_ns)
    return [(ADDRESS, build(self.template, direction, counter), BUS)]

  def _cancel(self, now_ns: int) -> list:
    if self.active is None:
      return []
    self.active["phase"] = "cancelling"
    self.active.setdefault("cancel_started_ns", int(now_ns))
    if self.active.get("cancel_attempts", 0) >= MAX_CANCEL_ATTEMPTS:
      self.active = None
      return []
    if not self._can_send(now_ns):
      return []
    if self.template is None or now_ns - self.template_ns > TEMPLATE_MAX_AGE_NS:
      self.active = None
      return []
    # The safety plugin requires template_counter + 1 for every frame; repeats are bounded by the 100 ms rate.
    counter = (decode(self.template)["counter"] + 1) % 16
    self.active["cancel_attempts"] = self.active.get("cancel_attempts", 0) + 1
    self.active["cancel_sent_ns"] = int(now_ns)
    return self._emit("cancel", counter, now_ns)

  def update(self, intent: dict, cs, cc, now_ns: int, *, enabled: bool) -> list:
    """Return CAN frames to append; the host checks the can.tx claim and panda validates each frame."""
    direction = str(intent.get("direction", "none"))
    # BRAKE_CANCEL_JUNCTION_EXEMPT：接近路口踩刹车是正常驾驶动作，
    # 不能因此取消「导航转弯灯」；只有并道类才把刹车当成放弃信号。
    _purpose = str(intent.get("signalPurpose", ""))
    _brake = bool(getattr(cs, "brakePressed", False))
    _brake_cancel = _brake and _purpose != "junction"
    # LAMP_DECOUPLED_FROM_LATERAL：导航转弯灯是「告诉后车我要转弯」，
    # 与横向控制是否激活无关；只有并道类灯才要求 latActive。
    _need_lat = _purpose != "junction"
    requested = bool(enabled and intent.get("valid") and intent.get("signalRequested")
                     and direction in ("left", "right")
                     and (bool(getattr(cc, "latActive", False)) or not _need_lat)
                     and not _brake_cancel)
    physical_left = bool(getattr(cs, "leftBlinker", False))
    physical_right = bool(getattr(cs, "rightBlinker", False))
    physical_on = physical_left if direction == "left" else physical_right
    # A driver-selected opposite side (including hazards) owns the lamps. Do
    # not send a cancel frame: that would also cancel the driver's new signal.
    owned = self.active['direction'] if self.active is not None else direction
    opposite_on = physical_right if owned == 'left' else physical_left if owned == 'right' else False
    if opposite_on:
      self.active = None
      return []

    if self.active is not None:
      age = now_ns - int(self.active["started_ns"])
      same = (direction == self.active["direction"] and intent.get("sessionId") == self.active["sessionId"]
              and int(intent.get("routeRevision", 0)) == self.active["routeRevision"]
              and int(intent.get("requestId", 0)) == self.active["requestId"])
      if self.active["phase"] == "cancelling":
        # Cancellation owns the lamp until CarState confirms it is off, or the bound expires.
        if not physical_left and not physical_right:
          self.active = None
        elif now_ns - int(self.active.get("cancel_started_ns", now_ns)) > CANCEL_TOTAL_TIMEOUT_NS:
          self.active = None
        else:
          return self._cancel(now_ns)
      if self.active is None:
        pass
      elif not same or age > SESSION_TIMEOUT_NS:
        return self._cancel(now_ns)
      elif _brake_cancel:
        return self._cancel(now_ns)
      elif not requested:
        # 不再无限期保持：以前这里在「灯已亮 + 导航有效」时直接 return []，
        # 结果是意图停止请求后灯还一直亮着（实测 17 秒以上），并且挡住新的反向机动。
        return self._cancel(now_ns)
      else:
        self.active["held"] = physical_on
        if physical_on:
          return []
        # 灯没亮就周期性重发，而不是 2.5 秒后放弃：
        # 车端变道需要灯持续亮着，提前放弃会让它永远不满足条件。
        if not self._can_send(now_ns):
          return []
        if now_ns - int(self.active.get("action_sent_ns", 0)) < RESEND_NS:
          return []
        if self.active.get("action_attempts", 0) >= MAX_ACTION_ATTEMPTS:
          self._failed_key = self._key(intent)
          return self._cancel(now_ns)
        if self.template is None or now_ns - self.template_ns > TEMPLATE_MAX_AGE_NS:
          return []
        counter = (decode(self.template)["counter"] + 1) % 16
        self.active["action_attempts"] = self.active.get("action_attempts", 0) + 1
        self.active["action_sent_ns"] = int(now_ns)
        return self._emit(direction, counter, now_ns)

    if not requested or self._key(intent) == self._failed_key or not self._can_send(now_ns):
      return []
    if physical_on:
      # The driver already signals this side: do not inject a duplicate frame.
      return []
    if self.template is None or now_ns - self.template_ns > TEMPLATE_MAX_AGE_NS:
      return []
    self.active = {
      "direction": direction, "sessionId": intent.get("sessionId"),
      "routeRevision": int(intent.get("routeRevision", 0)), "requestId": int(intent.get("requestId", 0)),
      "started_ns": int(now_ns), "action_sent_ns": int(now_ns), "action_attempts": 1, "phase": "active",
    }
    counter = (decode(self.template)["counter"] + 1) % 16
    return self._emit(direction, counter, now_ns)

  def diagnostics(self, intent, cs, cc, now_ns, *, enabled, frames):
    direction=intent.get('direction','none')
    left,right=bool(getattr(cs,'leftBlinker',False)),bool(getattr(cs,'rightBlinker',False))
    physical=left if direction=='left' else right if direction=='right' else False
    reason='waitingFeedback'
    if not enabled:reason='disabled'
    elif not intent.get('valid') or not intent.get('signalRequested'):reason='noRequest'
    elif not getattr(cc,'latActive',False):reason='lateralInactive'
    elif getattr(cs,'brakePressed',False):reason='driverBrake'
    elif (direction=='left' and right) or (direction=='right' and left):reason='driverOppositeSignal'
    elif physical:reason='physicalConfirmed'
    elif self._key(intent)==self._failed_key:reason='feedbackTimeout'
    elif self.template is None:reason='templateMissing'
    elif now_ns-self.template_ns>TEMPLATE_MAX_AGE_NS:reason='templateStale'
    if frames:reason='cancelBuilt' if decode(frames[-1][1])['turn']==3 else 'requestBuilt'
    return dict(reason=reason,framesBuilt=len(frames),physicalFeedback=physical,
      lastFrameBuiltAgeMs=None if self._last_send_ns is None else max(0,(now_ns-self._last_send_ns)//1_000_000),
      templateAgeMs=None if self.template is None else max(0,(now_ns-self.template_ns)//1_000_000))
